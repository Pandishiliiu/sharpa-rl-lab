from __future__ import annotations
import time
import sys
import os

import gymnasium as gym
import numpy as np
import torch
from collections.abc import Sequence
from typing import TYPE_CHECKING

from rl_isaaclab.utils.keyboard_listener import KeyboardListener, ThreadSafeValue
from rl_isaaclab.utils.misc import dof_sharpa2isaaclab, dof_isaaclab2sharpa
from pathlib import Path
from rl_isaaclab.utils.tactile_config import prepare_tactile_config
from rl_isaaclab.utils.tactile_validation import validate_tactile_frame
from rl_isaaclab.utils.tactile_freshness import check_tactile_freshness

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '../../utils/python'))
from sharpa import (
    SharpaWaveManager,
    ControlMode,
    ControlSource,
    SharpaWaveConfig,
)

if TYPE_CHECKING:
    from .sharpa_wave_deploy_env_cfg import SharpaWaveEnvCfg


class SharpaWaveInhandRotateDeployEnv(gym.Env):
    cfg: SharpaWaveEnvCfg

    def __init__(self, cfg: SharpaWaveEnvCfg, render_mode: str | None = None, **kwargs):
        self.cfg = cfg
        self.num_envs = 1
        self.num_hand_dofs = self.cfg.action_space
        self.device = self.cfg.device
        self.num_actions = self.cfg.action_space
        self.observation_space = self.cfg.observation_space

        # change tactile config
        if not self.change_tactile_config(on_board=self.cfg.enable_on_board):
            print(f'Failed to change tactile config')
            exit(1)

        # tactile buffers
        CHANNEL = range(0+5*(1-self.cfg.hand_side), 5+5*(1-self.cfg.hand_side))
        self.frames = {ch: [None, None, None, None] for ch in CHANNEL}
        self.tactile_last_seen = {}
        self.frames_raw = {ch: [None, None, None, None] for ch in CHANNEL}
        # deform mapping
        self.tac_uv_map = [np.load('assets/tactile_ha4_map/tactileSensor_map_4F_point.npy')] * 4
        self.tac_uv_map.append(np.load('assets/tactile_ha4_map/tactileSensor_map_TH_point.npy'))

        # init hand
        self._init_hand()

        # init config
        self.target_dt = 1.0 / self.cfg.control_freq

        # buffers for position targets
        self.prev_targets = torch.zeros((self.num_envs, self.num_hand_dofs), dtype=torch.float, device=self.device)
        self.cur_targets = torch.zeros((self.num_envs, self.num_hand_dofs), dtype=torch.float, device=self.device)

        # buffers for data
        self.obs_buf_lag_history = torch.zeros((self.num_envs, 80, self.cfg.observation_space//3), device=self.device, dtype=torch.float)
        self.at_reset_buf = torch.ones(self.num_envs, device=self.device, dtype=torch.long)
        self.proprio_hist_buf = torch.zeros((self.num_envs, self.cfg.prop_hist_len, self.cfg.observation_space//3), device=self.device, dtype=torch.float)
        self.obs_buf = {
            "policy": torch.zeros(
                (self.num_envs, self.cfg.observation_space),
                device=self.device,
                dtype=torch.float,
            ),
            "proprio_hist": self.proprio_hist_buf,
        }

        # joint limits
        self.hand_dof_lower_limits = torch.tensor(
            [-0.1745, -0.1745, 0.0000, -0.1745, -0.1745, -0.3491, -0.3491, -0.1745, -0.3491, -0.3491, 0.0000,
             0.0000, -0.3491, 0.0000, -0.5236, 0.0000, 0.0000, 0.0000, 0.0000, -0.3491, 0.0000, 0.0000],
        device=self.device).reshape(1, -1) * self.cfg.dof_limits_scale
        self.hand_dof_upper_limits = torch.tensor(
            [1.5708, 1.5708, 0.2618, 1.5708, 1.9199, 0.3491, 0.3491, 1.5708, 0.3491, 0.3491, 1.7453,
             1.7453, 0.3491, 1.7453, 1.3963, 1.3963, 1.3963, 1.7453, 1.3963, 0.3491, 1.3963, 1.7453],
        device=self.device).reshape(1, -1) * self.cfg.dof_limits_scale

        # contact buffers
        self._contact_body_ids = torch.tensor([0, 1, 2, 3, 4], dtype=torch.long)
        self._contact_body_ids_disable = torch.tensor([], dtype=torch.long)
        self.last_contacts = torch.zeros((self.num_envs, len(self._contact_body_ids)), dtype=torch.float, device=self.device)

        # episode length
        self.episode_length_buf = torch.zeros(self.num_envs, device=self.device, dtype=torch.long)
        self._last_step_wall = time.perf_counter()

        # keyboard
        if self.cfg.keyboard_listen:
            self.deploy_state_flag = ThreadSafeValue(4)
            self.calib_tactile_flag = ThreadSafeValue(0)
            self.keyboard_proc = KeyboardListener(self.deploy_state_flag,
                                                  self.calib_tactile_flag,
                                                  hand_ip=self.hand_info.ip)
            self.keyboard_proc.start()
            # signal.signal(signal.SIGINT, self.signal_handler)

    def tactile_callback(self, frame):
        # 1. 校验触觉帧
        result = validate_tactile_frame(
            frame,
            self.cfg.hand_side,
        )

        if result is None:
            return

        ch, force_norm = result
        content = frame["content"]

        # 2. 读取原始图像（可选）
        img = content.get("RAW")

        if img is not None and hasattr(img, "squeeze"):
            img = img.squeeze()
        else:
            img = None

        # 3. 计算有效接触力
        f_norm = torch.tensor(
            force_norm,
            dtype=torch.float32,
            device=self.device,
        )

        # 4. 初始化接触位置
        contact_pos = torch.zeros(
            (3,),
            dtype=torch.float32,
            device=self.device,
        )

        # 5. 尝试解析接触点
        points = content.get("CONTACT_POINT")

        if points is not None:
            try:
                p = torch.as_tensor(
                    points,
                    dtype=torch.float32,
                ).reshape(-1, 3)

                if p.numel() > 0 and bool(torch.isfinite(p).all()):
                    centroid = p[torch.argmax(p[:, 2])]

                    x = int(centroid[0])
                    y = int(centroid[1])

                    local_ch = ch - 5 * (1 - self.cfg.hand_side)
                    uv_map = self.tac_uv_map[local_ch]

                    if (
                        0 <= y < uv_map.shape[0]
                        and 0 <= x < uv_map.shape[1]
                    ):
                        contact_pos = torch.as_tensor(
                            uv_map[y, x][:3],
                            dtype=torch.float32,
                            device=self.device,
                        ) / 1000.0

            except (TypeError, ValueError, IndexError, RuntimeError):
                pass

        # 6. 只有校验通过的触觉帧才能更新缓存
        self.frames[ch] = (
            img,
            f_norm,
            None,
            contact_pos,
        )
        self.tactile_last_seen[ch] = time.monotonic()

    def close(self):
        """Release SDK and listener resources.

        This is NOT a motor emergency stop.
        """

        # Prevent duplicate cleanup.
        if getattr(self, "_closed", False):
            return

        self._closed = True

        # 1. Request software Standby.
        flag = getattr(self, "deploy_state_flag", None)

        if flag is not None:
            try:
                flag.set(4)
            except Exception as exc:
                print(f"[CLOSE] State update failed: {exc}")

        # 2. Stop keyboard listener.
        listener = getattr(self, "keyboard_proc", None)

        if listener is not None:
            try:
                listener.stop()
            except Exception as exc:
                print(f"[CLOSE] Keyboard cleanup failed: {exc}")

        # 3. Stop tactile acquisition.
        hand = getattr(self, "hand", None)

        if hand is not None:
            try:
                hand.stop()
            except Exception as exc:
                print(f"[CLOSE] Tactile cleanup failed: {exc}")

            # 4. Disconnect SDK devices.
            try:
                SharpaWaveManager.get_instance().disconnect_all()
            except Exception as exc:
                print(f"[CLOSE] SDK disconnect failed: {exc}")

        print("[CLOSE] Resource cleanup attempted.")

    def reset(self, seed=None, options=None):
        """Reset environment after tactile sensors become ready."""

        deploy_state = (
            self.deploy_state_flag.get()
            if self.cfg.keyboard_listen
            else 3
        )

        # Initial software Standby must not read tactile data or command joints.
        if deploy_state == 4:
            return self.obs_buf, None

        # 1. Wait for valid tactile observations.
        if self.cfg.enable_tactile:

            timeout = 5.0
            deadline = time.monotonic() + timeout

            while True:
                status = self.get_tactile_status()

                if status["ready"]:
                    print("[Tactile] All required channels ready")
                    break

                if time.monotonic() >= deadline:
                    raise TimeoutError(
                        "Tactile initialization timeout: "
                        f"missing={status['missing']}, "
                        f"stale={status['stale']}"
                    )

                time.sleep(0.05)

        # 2. Original reset logic.
        indices = torch.arange(
            self.num_envs,
            dtype=torch.int64,
            device=self.device,
        )

        self._reset_idx(indices)

        # 3. Return observations.
        self.obs_buf = self._get_observations()
        return self.obs_buf, None

    def _init_hand(self):
        self.hand = self.auto_detect_hand()
        if self.hand is None:
            print("Error: No available device found")
            exit(1)
        self.hand_info = self.hand.get_device_info()
        print("Sharpa Wave Example - Init Hand Running Mode")
        if not self.initialize():
            print("Error: Failed to initialize hand")
            exit(1)
        self.hand.start()

    def auto_detect_hand(self):
        """Automatically detect device and return device and device serial number"""
        print("Searching for devices...")

        try:
            manager = SharpaWaveManager.get_instance()
            time.sleep(1)  # Wait for 1 seconds for device discovery to complete
            while True:
                devices = manager.get_all_device_sn()
                if not devices:
                    print("No available devices found")
                    time.sleep(1)
                    continue
                else:
                    sn_id = 0
                    print(f"Device found: {devices[sn_id]}")
                    cfg = SharpaWaveConfig()
                    cfg.tactile_config_file = self.tactile_config_path
                    return manager.connect(devices[sn_id], cfg)
        except Exception as e:
            print(f"Failed to connect to device: {str(e)}")
            exit(1)

    def initialize(self):
        control_mode = getattr(ControlMode, getattr(self.cfg, "control_mode", "POSITION"))
        error = self.hand.set_control_mode(control_mode)
        if error.code != 0:
            print(f"Failed to set control mode: {error.message}")
            return False
        error = self.hand.set_speed_coeff(getattr(self.cfg, "speed_coef", 0.5))
        if error.code != 0:
            print(f"Failed to set speed coeff: {error.message}")
            return False

        error = self.hand.set_current_coeff(getattr(self.cfg, "current_coef", 0.3))
        if error.code != 0:
            print(f"Failed to set current coeff: {error.message}")
            return False
        control_source = getattr(ControlSource, getattr(self.cfg, "control_source", "SDK"))
        error = self.hand.set_control_source(control_source)
        if error.code != 0:
            print(f"Failed to set control source: {error.message}")
            return False
        if not self.init_tactile():
            print(f'Failed to initialize tactile')
            return False
        return True

    def init_tactile(self):
        # set tactile callback
        self.hand.set_tactile_callback(self.tactile_callback)
        return True

    def change_tactile_config(self, on_board=None):
        """Prepare a tactile config compatible with Sharpa SDK v5.0.11."""

        if on_board is None:
            on_board = True

        try:
            source_path = Path(
                "/opt/sharpa-wave-sdk/config/tactile.json"
            )

            side = "left" if self.cfg.hand_side == 0 else "right"

            output_path = (
                Path.home()
                / ".config"
                / "sharpa-rl-lab"
                / f"tactile_{side}.json"
            )

            prepared_path = prepare_tactile_config(
                source_path=source_path,
                output_path=output_path,
                hand_side=self.cfg.hand_side,
                on_board=on_board,
            )

            self.tactile_config_path = str(prepared_path)

            print(
                f"[TactileConfig] Config prepared: "
                f"{self.tactile_config_path}"
            )

            return True

        except (OSError, ValueError, TypeError) as e:
            print(f"[TactileConfig] Configuration error: {e}")
            return False

    def _pre_physics_step(self, actions: torch.Tensor) -> None:
        actions = saturate(actions, torch.tensor(-self.cfg.clip_actions), torch.tensor(self.cfg.clip_actions))
        self.actions = actions.clone()
        targets = self.prev_targets + self.cfg.action_scale * self.actions      #策略输出的不是绝对角度，而是在当前目标基础上增加一个控制增量
        self.cur_targets = saturate(targets, self.hand_dof_lower_limits, self.hand_dof_upper_limits)        #再次限制目标关节角度

    def _apply_action(self) -> None:        #把目标角度发送给机器人
        self._refresh_lab()
        command = dof_isaaclab2sharpa(self.cur_targets.squeeze()).cpu().numpy()         #Isaac Lab 和 Sharpa SDK 的22个关节可能采用不同的排列顺序，转换
        self.hand.set_joint_position(command)       #将目标位置交给 SDK
        self.prev_targets = self.cur_targets.clone()        #保存本次目标

    def _get_observations(self) -> dict:
        self._refresh_lab()
        obs = self.compute_observations()
        observations = {
            "policy": obs,
            "proprio_hist": self.proprio_hist_buf,
        }
        return observations

    def step(self, action):
        # 1. 获取当前控制状态
        if self.cfg.keyboard_listen:
            deploy_state = self.deploy_state_flag.get()
        else:
            deploy_state = 3

        # 2. Standby 不需要有效触觉数据
        # Reset 使用专门的控制权限和触觉检查
        if deploy_state == 2:
            self._check_reset_gate("step_entry")

        # 其他非 Standby 状态使用常规触觉检查
        elif self.cfg.enable_tactile and deploy_state != 4:
            status = self.get_tactile_status()

            if not status["ready"]:
                raise RuntimeError(
                    "Tactile data unavailable: "
                    f"missing={status['missing']}, "
                    f"stale={status['stale']}"
                )
        if self.cfg.keyboard_listen:
            # tactile
            if self.calib_tactile_flag.get() == 1:
                self.calib_tactile()
                self.calib_tactile_flag.set(0)
            # deploy state
            if deploy_state == 0:
                self.hand.set_joint_position([0] * 22)
            elif deploy_state == 1:
                freeze_actions = self.hand.get_states().angles
                self.hand.set_joint_position(freeze_actions)
            elif deploy_state == 2:
                self._reset_idx([0])
            elif deploy_state == 3:
                action = action.to(self.device)
                self._pre_physics_step(action)
                self._apply_action()

            elif deploy_state == 4:
                # Standby: do not issue joint position commands.
                pass

            else:
                freeze_actions = self.hand.get_states().angles
                self.hand.set_joint_position(freeze_actions)
        else:
            action = action.to(self.device)
            self._pre_physics_step(action)
            self._apply_action()
        loop_dt = time.perf_counter() - self._last_step_wall
        if loop_dt < self.target_dt:
            time.sleep(self.target_dt - loop_dt)
        self._last_step_wall = time.perf_counter()
        self.episode_length_buf += 1

        # Standby: keep the last valid observation.
        # No new tactile observation is generated.
        if deploy_state != 4:
            self.obs_buf = self._get_observations()

        return self.obs_buf, None, None, None, None

    def _check_reset_gate(self, stage):
        """Check reset authorization and tactile freshness."""

        # 1. 检查 Reset 控制状态
        if self.cfg.keyboard_listen:
            state = self.deploy_state_flag.get()

            if state != 2:
                raise RuntimeError(
                    f"[Reset:{stage}] Cancelled: control state={state}"
                )

        # 2. 检查触觉数据
        if self.cfg.enable_tactile:
            status = self.get_tactile_status()

            if not status["ready"]:
                if self.cfg.keyboard_listen:
                    self.deploy_state_flag.set(4)

                raise RuntimeError(
                    f"[Reset:{stage}] Tactile unavailable: "
                    f"missing={status['missing']}, "
                    f"stale={status['stale']}"
                )

    def _reset_idx(self, env_ids: Sequence[int] | None):
        # Standby: do not execute reset motions before authorization.
        if self.cfg.keyboard_listen:
            if self.deploy_state_flag.get() == 4:
                return

        self._check_reset_gate("start")

        if self.cfg.warm_up:
            error = self.hand.set_speed_coeff(0.3)
            error = self.hand.set_current_coeff(self.cfg.current_coef)

            self._check_reset_gate("before_home")
            self.hand.set_joint_position([0] * 22)

            # 等待3秒，但每50ms检查一次
            deadline = time.monotonic() + 3.0

            while time.monotonic() < deadline:
                self._check_reset_gate("home_wait")

                remaining = deadline - time.monotonic()

                if remaining > 0:
                    time.sleep(min(0.05, remaining))

        if env_ids is None:
            env_ids = self.hand._ALL_INDICES
        self.episode_length_buf[env_ids] = 0

        error = self.hand.set_speed_coeff(self.cfg.speed_coef)
        error = self.hand.set_current_coeff(self.cfg.current_coef)

        # reset hand
        if self.cfg.warm_up:
            # replay traj until grasp
            traj = np.load('cache/deploy_init_traj.npy')
            self._check_reset_gate("before_trajectory")

            tactile_force, _ = self.get_tactile_info()
            j = 0

            self._check_reset_gate("trajectory_start")
            self.hand.set_joint_position(traj[j])
            while torch.max(tactile_force) < 1 and j + 3 < len(traj):

                self._check_reset_gate("trajectory_step")

                j += 1
                self.hand.set_joint_position(traj[j])

                time.sleep(0.03)

                self._check_reset_gate("trajectory_read")
                tactile_force, _ = self.get_tactile_info()

            print(f"pick num {j} traj in {len(traj)}")
            self.prev_targets[env_ids] = dof_sharpa2isaaclab(torch.tensor(traj[j+2], dtype=torch.float32, device=self.device))
            self.cur_targets[env_ids] = dof_sharpa2isaaclab(torch.tensor(traj[j+2], dtype=torch.float32, device=self.device))

        self._refresh_lab()

        # reset data buffers
        self.last_contacts[env_ids] = 0
        self.proprio_hist_buf[env_ids] = 0
        self.at_reset_buf[env_ids] = 1

        # Reset completed successfully.
        self._check_reset_gate("finish")

        if self.cfg.keyboard_listen:
            self.deploy_state_flag.set(3)

    def _refresh_lab(self):         #SDK 获取当前关节角度，转换为 Isaac Lab 的顺序，保存到 hand_dof_pos， 转换成神经网络需要的张量
        self.hand_dof_pos = dof_sharpa2isaaclab(torch.tensor(self.hand.get_states().angles)).reshape(1, -1).to(self.device)

    def compute_observations(self):
        # contact               将原始数据组织成策略观测向量
        sensed_contacts, contact_pos = self.get_tactile_info()
        # deal with normal observation, do sliding window
        prev_obs_buf = self.obs_buf_lag_history[:, 1:].clone()
        cur_obs_buf = unscale(self.hand_dof_pos, self.hand_dof_lower_limits, self.hand_dof_upper_limits).clone().unsqueeze(1)
        cur_tar_buf = self.cur_targets.unsqueeze(1)
        cur_obs_buf = torch.cat([cur_obs_buf, cur_tar_buf], dim=-1)
        cur_obs_buf = torch.cat([cur_obs_buf, sensed_contacts.unsqueeze(1), contact_pos.unsqueeze(1)], dim=-1)
        self.obs_buf_lag_history[:] = torch.cat([prev_obs_buf, cur_obs_buf], dim=1)

        # refill the initialized buffers
        at_reset_env_ids = self.at_reset_buf.nonzero(as_tuple=False).squeeze(-1)
        self.obs_buf_lag_history[at_reset_env_ids, :, 0:22] = unscale(
            self.hand_dof_pos[at_reset_env_ids],
            self.hand_dof_lower_limits[at_reset_env_ids],
            self.hand_dof_upper_limits[at_reset_env_ids],
        ).clone().unsqueeze(1)
        self.obs_buf_lag_history[at_reset_env_ids, :, 22:44] = self.hand_dof_pos[at_reset_env_ids].unsqueeze(1)
        self.obs_buf_lag_history[at_reset_env_ids, :, 44:49] = sensed_contacts[at_reset_env_ids].unsqueeze(1)
        self.obs_buf_lag_history[at_reset_env_ids, :, 49:64] = contact_pos[at_reset_env_ids].unsqueeze(1)
        self.at_reset_buf[at_reset_env_ids] = 0
        obs_buf = (self.obs_buf_lag_history[:, -3:].reshape(self.num_envs, -1)).clone()         #64=22+22+5+15维取最近3帧变成192维

        self.proprio_hist_buf[:] = self.obs_buf_lag_history[:, -self.cfg.prop_hist_len:].clone()

        return obs_buf

    def calib_tactile(self):
        # calibrate tactile
        if not self.hand.calib_tactile():
            print(f'Tactile calibration failed')
            return False
        else:
            print(f'Tactile calibration successful')
            return True

    def get_tactile_status(self, max_age=0.5):
        """Check whether required tactile channels are fresh."""

        if not self.cfg.enable_tactile:
            return {
                "ready": True,
                "missing": [],
                "stale": [],
            }

        return check_tactile_freshness(
            last_seen=self.tactile_last_seen.copy(),
            hand_side=self.cfg.hand_side,
            disabled_fingers=self.cfg.disable_tactile_ids,
            max_age=max_age,
        )

    def get_tactile_info(self):
        # 1. 检查触觉数据是否有效
        if self.cfg.enable_tactile:
            status = self.get_tactile_status()

            if not status["ready"]:
                raise RuntimeError(
                    "Tactile observation unavailable: "
                    f"missing={status['missing']}, "
                    f"stale={status['stale']}"
                )
        force = torch.zeros(5, dtype=torch.float32, device=self.device)
        contact_pos = torch.zeros((5, 3), dtype=torch.float32, device=self.device)

        if not self.cfg.enable_tactile:
            return force.reshape(1, -1), contact_pos.reshape(1, -1)

        # get tactile data
        for finger in range(5):

            # 禁用的手指不要求触觉数据
            if finger in self.cfg.disable_tactile_ids:
                continue

            channel = 4 - finger + 5 * (1 - self.cfg.hand_side)

            _, f_norm, _, contact_pos_ch = self.frames[channel]

            # 防止时间戳与缓存状态不一致
            if f_norm is None or contact_pos_ch is None:
                raise RuntimeError(
                    f"Tactile cache incomplete: channel={channel}"
                )

            force[finger] = f_norm
            contact_pos[finger] = contact_pos_ch

        # check disable
        force[self.cfg.disable_tactile_ids] = 0.0
        contact_pos[self.cfg.disable_tactile_ids] = 0.0

        if not self.cfg.enable_contact_pos:
            contact_pos[:] = 0.0

        # check thresh
        force *= self.cfg.force_scale       #对力的模长进行比例缩放，配置文件里面写的是/1.5
        force[force < self.cfg.contact_threshold] = 0.0         #设置阈值，如果规范力信息小于0.2，就直接置零
        if self.cfg.binary_contact:
            force = torch.where(force > self.cfg.contact_threshold, 1.0, 0.0)
        contact_pos[force < self.cfg.contact_threshold] = 0.0

        return force.reshape(1, -1), contact_pos.reshape(1, -1)

    def go_home(self):
        self.hand.set_joint_position([0] * 22)
        time.sleep(3)


@torch.jit.script
def saturate(x: torch.Tensor, lower: torch.Tensor, upper: torch.Tensor) -> torch.Tensor:
    return torch.max(torch.min(x, upper), lower)

@torch.jit.script
def unscale(x, lower, upper):
    return (2.0 * x - upper - lower) / (upper - lower)
